# -*- coding: utf-8 -*-

import mrp
import mrp_config_settings